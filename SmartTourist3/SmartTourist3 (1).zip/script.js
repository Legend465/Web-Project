const messagesContainer = document.getElementById("messages");
const userInput = document.getElementById("userInput");
const sendBtn = document.getElementById("sendBtn");
const pharaohImage = document.getElementById("pharaohImage");
const chatContainer = document.querySelector("main");

sendBtn.addEventListener("click", async () => {
  const text = userInput.value.trim();
  if (!text) return;
  
  addMessage(text, "user");
  userInput.value = "";
  
  if (text.includes("رمسيس")) {
    chatContainer.classList.add("shift-left");
    showPharaoh("assets/ramses.png");
  } else if (text.includes("تحتمس")) {
    chatContainer.classList.add("shift-left");
    showPharaoh("assets/thutmose.png");
  }
  
  const reply = await askGemini(text);
  await typeMessage(reply);
  
  hidePharaoh();
});

function addMessage(content, type) {
  const msg = document.createElement("div");
  msg.classList.add("message", type);
  msg.textContent = content;
  messagesContainer.appendChild(msg);
  messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

async function typeMessage(text) {
  const msg = document.createElement("div");
  msg.classList.add("message", "bot");
  messagesContainer.appendChild(msg);
  
  for (let i = 0; i < text.length; i++) {
    msg.textContent += text[i];
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
    await new Promise(res => setTimeout(res, 40));
  }
  
  setTimeout(() => {
    chatContainer.classList.remove("shift-left");
  }, 2500);
}

function showPharaoh(imgPath) {
  pharaohImage.src = imgPath;
  pharaohImage.classList.add("visible");
}

function hidePharaoh() {
  setTimeout(() => {
    pharaohImage.classList.remove("visible");
  }, 4000);
}